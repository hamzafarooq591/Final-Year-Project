var tokenValue = "cbfaf390-7fe7-4e24-9510-97c2b8f81926";
function fillTestList(){
    showLoader();
        $.ajax({
            url: ' '+ nashApi + '/api/Test',
            type: 'GET',
            datatype: 'json',
            headers: { 'token': tokenValue },
            success: function (data) {
                var value = data.data;
                fillTestListContent(value);
                hideLoader();
            },
            error: function (request, message, error) {
                hideLoader();
                console.log(error);
            }
        });
}

function fillTestListContent(valueList) {
    var testContent = '';
    $.each(valueList, function (index, value) {
        testContent += '<div id="testBookAppointment'+value.testId+'" class="row" style="border-bottom:1px solid #80808047;padding:7px">'; 
        testContent += '<div class="col-1" style="font-weight: bold;"><input onchange="addTestForPrice('+value.testId+')" type="checkbox" id="'+ value.testId +'"></div>';            
        testContent += '<div class="col-7" style="font-weight: bold;">'+ value.title +'</div>';            
        testContent += '<div class="col-4">'+ value.price +'</div>';            
        testContent += '</div>';        
    });
    document.getElementById('testOfferBookAppointment').innerHTML = testContent;
  }

  function fillOfferList(){
    showLoader();
        $.ajax({
            url: ' '+ nashApi + '/api/Offer',
            type: 'GET',
            datatype: 'json',
            headers: { 'token': tokenValue },
            success: function (data) {
                var value = data.data;
                fillOfferListContent(value)
                hideLoader();
            },
            error: function (request, message, error) {
                hideLoader();
                console.log(error);
            }
        });
}

function fillOfferListContent(valueList) {
    var offerContent = '';
    $.each(valueList, function (index, value) {
        offerContent += '<div class="row" style="border-bottom: 1px solid #80808047;padding-bottom: 25px;padding-top: 20px;">'; 
        offerContent += '<div class="col-8" style="font-weight: bolder;">'+value.title+'</div>'; 
        offerContent += '<div class="col-4"><button style="width: 100%;height: 100%;background: #b4c8db;border: lightgray;border-radius: 5px;font-size: 11px;">Book Appointment</button></div>'; 
        offerContent += ' <div class="row" style="width: 100%;">'; 
        offerContent += '<div class="col-2" style="padding-right: 0px;text-decoration: line-through;font-size: 15px;">'+ value.oldPrice +'</div>'; 
        offerContent += '<div class="col-2" style="padding-right: 0px;color: #090986;font-weight: bold;font-size: 15px;">'; 
        offerContent += ''+ value.newPrice +'</div>';
        offerContent += '</div>';
        offerContent += '</div>';
    });
    document.getElementById('discountOfferBookAppointment').innerHTML = offerContent;
  }

  function addTestForPrice(divValues){
      debugger
      var a = divValues.toString();
      var testSummaryDiv = document.getElementById('testSummary');
      var inputValue = document.getElementById(a);
      var divName = "testBookAppointment"+divValues;
      var mainDiv = document.getElementById(divName);
      var valueTitle = mainDiv.childNodes[1].innerText;
      var valuePrice = mainDiv.lastElementChild.innerText;
      var addRow = '';
      if(inputValue.checked == true){
      if(testSummaryDiv.childElementCount == 0){
      addRow += '<div class="row" style="border-bottom:1px solid #80808047">';
      addRow += '<div class="col-8" style="font-weight: bold;">'+valueTitle+'</div>';
      addRow += '<div class="col-4">'+valuePrice+'</div>';
      document.getElementById('testSummary').innerHTML = addRow; 
      }
      else{
      addRow += '<div class="row" style="border-bottom:1px solid #80808047">';
      addRow += '<div class="col-8" style="font-weight: bold;">'+valueTitle+'</div>';
      addRow += '<div class="col-4">'+valuePrice+'</div>';
      $('#testSummary').append(addRow);  
      }
    }
    else{
        debugger;
    }

  }