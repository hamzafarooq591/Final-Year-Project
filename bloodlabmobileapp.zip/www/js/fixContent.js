var nashApi = 'http://nash.pk:8991';

function showLoader() {
  document.getElementById("overlay").style.display = "block";
}

function hideLoader() {
  document.getElementById("overlay").style.display = "none";
}

function setLocalStorage(c_name, value) {
  localStorage.setItem(c_name, value);
}

function getLocalStorage(name) {
  var data = localStorage.getItem(name);
  return JSON.parse(data);
}

function getTodayDate() {
  var today = new Date();
  var day = today.getDay();
  var daylist = ["Sunday","Monday","Tuesday","Wednesday ","Thursday","Friday","Saturday"];
  var dayName = daylist[day];
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
  var monthlist = ["Jan","Feb","Mar","Apr ","May","June","July","Aug","Sep","Oct","Nov","Dec"];
  var monthName = monthlist[mm];
  var yyyy = today.getFullYear();
  //today = mm + '/' + dd + '/' + yyyy;
  today = dayName + "," + dd + " " + monthName
  // document.write(today);
}

function mainFooter() {
  var mainFooterContent = '';
  mainFooterContent += '<div  class="container-flex row" style="background-color: white;height: 65px; position: fixed;bottom: 0;text-align: center;width: 100%;z-index:10001">';
  mainFooterContent += '<div onclick="goToLandingPage()" class="col-2" id="footerBackgroundHome" style="padding-top: 15px;height: 100%;margin-right: 5px;">';
  mainFooterContent += '<a> <img class="footer" style="width: 60%;" src="img/001-Home.svg" alt="">';
  mainFooterContent += '<p style="font-size: 12px;color: gray;">Home</p>';
  mainFooterContent += '</a>';
  mainFooterContent += '</div>';

  mainFooterContent += '<div onclick="" class="col-2" id="footerBackgroundOrder" style="padding-top: 15px;height: 100%;margin-right: 5px;">';
  mainFooterContent += '<a><img class="footer" style="width: 60%;" src="img/002-Order.svg" alt="">';
  mainFooterContent += '<p style="font-size: 12px;color: gray;">Order</p>';
  mainFooterContent += '</a>';
  mainFooterContent += '</div>';

  mainFooterContent += '<div class="col-3" id="footerBackgroundAdd" onclick="goToBookAppointmentPage()" style="padding-top: 15px;height: 100%;margin-right: 5px;">';
  mainFooterContent += '<a><img class="footer" style="width: 70% !important;" src="img/circle.png" alt="">';
  // mainFooterContent += '<p style="font-size: 12px;color: gray;">Order</p>';
  mainFooterContent += '</a>';
  mainFooterContent += '</div>';

  mainFooterContent += '<div onclick="goToProfilePage()" class="col-2" id="footerBackgroundProfile" style="padding-top: 15px;height: 100%;margin-right: 5px;">';
  mainFooterContent += '<a><img class="footer" style="width: 60%;" src="img/003-Profile.svg" alt="">';
  mainFooterContent += '<p style="font-size: 12px;color: gray;">Profile</p>';
  mainFooterContent += '</a>';
  mainFooterContent += '</div>';

  mainFooterContent += '<div onclick="goToNeedHelpPage()" class="col-2" id="footerBackgroundHelp" style="height: 100%;padding-top: 15px;padding-left: 0px !important;padding-right: 0px !important;margin-right: 5px;">';
  mainFooterContent += '<a><img class="footer" style="width: 60%;padding: 0px 8px;" src="img/004-Need Help.svg" alt="">';
  mainFooterContent += '<p style="font-size: 11px;color: gray;">Need Help</p>';
  mainFooterContent += '</a>';
  mainFooterContent += '</div>';
  mainFooterContent += '</div>';

  document.getElementById('mainFooterDiv').innerHTML = mainFooterContent;

}